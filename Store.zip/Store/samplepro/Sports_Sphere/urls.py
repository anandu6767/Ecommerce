from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings
from .import views 
app_name='samplepro'

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.index,name='index'),
    path('reg/',views.reg,name='register'),
    path('log/',views.log,name='login'),
    path('sellerregi/',views.sellerregi,name='sellerreg'),
    path('sellerlog/',views.sellerlog,name='sellerlog'),
    path('userhome/',views.userhome,name='userhome'),
    path('sellerhome/',views.sellerhome,name='sellerhome'),
    path('logout/',views.logout,name='logout'),
    path('addprod/',views.addprod,name='addprod'),
    path('viewproduct/<str:category>/', views.viewproduct, name='viewproduct'),
    path('add_cart/',views.add_cart,name='add_cart'),
    path('cart/<int:id>/',views.cart,name='cart'),
    path('viewcart/',views.viewcart,name='viewcart'),
    path('delete/<int:id>/',views.delete,name='delete'),
    path('paylist/',views.paylist,name='paylist'),
    path('accept/<int:id>',views.accept, name='accept'),
    
    path('userprofile/',views.userprofile,name='userprofile'),
    path('updatepro/',views.updatepro,name='updatepro'),
    path('proupdate/',views.proupdate,name='proupdate'),
    
    path('sellerprofile/',views.sellerprofile,name='sellerprofile'),
    path('sellerpro/',views.sellerpro,name='sellerpro'),
    path('proseller/',views.proseller,name='proseller'),
    
    
    
    path('payment/',views.payment,name='payment'),
    path('paymenthandler/', views.paymenthandler, name='paymenthandler'),
    
    path('search/',views.search,name='search'),
    
    
   
    # Other URL patterns
   
    # path('product_list/', views.product_list, name='product_list'),
    # path('update_product_status/<int:product_id>/', views.update_product_status, name='update_product_status'),
    path('payment_list/', views.payment_list, name='payment_list'),
    path('payment_list/<int:product_id>/', views.payment_list, name='payment_list_with_product'),

    path('update_payment_status/<int:payment_id>/', views.update_payment_status, name='update_payment_status'),
    
    path('sorted_product_list/', views.sorted_product_list, name='sorted_product_list'),
    path('delreg/',views.delreg, name='delreg'),
    path('delilog/',views.delilog, name='delilog'),
    path('sellerdellist/',views.sellerdellist, name='sellerdellist'),
]

    





urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
