from django.contrib import admin
from .models import userreg,sellerreg,addproduct,Cartitem,pay
# Register your models here.
admin.site.register(userreg)
admin.site.register(sellerreg)
admin.site.register(addproduct)
admin.site.register(Cartitem)
admin.site.register(pay)
