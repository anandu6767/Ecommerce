from django.apps import AppConfig


class SportsSphereConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Sports_Sphere'
