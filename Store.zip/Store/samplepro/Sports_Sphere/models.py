from django.db import models

# Create your models here.
class userreg(models.Model):
    name=models.CharField(max_length=100)
    email=models.EmailField(max_length=100)
    password=models.CharField(max_length=100)
    phone=models.IntegerField()
    address=models.CharField(max_length=100)
    
    
class sellerreg(models.Model):
    name=models.CharField(max_length=100)
    email=models.EmailField(max_length=100)
    password=models.IntegerField()
    phone=models.IntegerField()

class addproduct(models.Model):
    productname=models.CharField(max_length=100)
    category=models.CharField(max_length=100)
    price=models.IntegerField(max_length=100)
    quantity= models.IntegerField(max_length=20)
    image=models.ImageField(upload_to='proimage/')
    description=models.CharField(max_length=100)
    size=models.IntegerField(max_length=100)
    gender=models.CharField(max_length=100)


    def __str__(self):
        return self.productname
    
class Cartitem(models.Model):
    email=models.EmailField()
    # user = models.ForeignKey(userreg, on_delete=models.CASCADE)
    product= models.CharField(max_length=30)
    # product = models.ForeignKey(addproduct, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    price = models.IntegerField()
    image=models.ImageField(upload_to='proimage/')
    total=models.IntegerField()
    
class pay(models.Model):
    name=models.CharField(max_length=30)
    email=models.EmailField()
    product= models.CharField(max_length=30)
    price = models.IntegerField()
    
    PENDING = 'pending'
    SOLVING = 'Delivered'

    STATUS_CHOICES = [
        (PENDING, 'Pending'),
        (SOLVING, 'Delivered'),
        
    ]
    status = models.CharField(max_length=15, choices=STATUS_CHOICES, default=PENDING)
    send_to_delivery_agent = models.BooleanField(default=False)
    
    




