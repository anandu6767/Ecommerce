from django import forms
from .models import addproduct

class ProductStatusForm(forms.ModelForm):
    class Meta:
        model = addproduct
        fields = ['status']
