import smtplib
from django.http import HttpResponseBadRequest
from django.views.decorators.csrf import csrf_exempt
from django.core.mail import send_mail
from django.http import Http404
import smtplib
from django.shortcuts import get_object_or_404
from django.contrib import messages
from django.http import HttpResponse



import razorpay #import this
from django.conf import settings
from django.http import JsonResponse #import this
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt #import this
from django.http import HttpResponseBadRequest #import this
razorpay_client = razorpay.Client(
    auth=(settings.RAZOR_KEY_ID, settings.RAZOR_KEY_SECRET))


from django.shortcuts import render,redirect
from . models import userreg,sellerreg,addproduct,Cartitem,pay
from django.contrib import messages
# Create your views here.
def index(request):
    return render(request,'index.html')
def reg(request):
    if request.method=='POST':
        name=request.POST.get('name')
        email=request.POST.get('email')
        password=request.POST.get('password')
        phone=request.POST.get('phone')
        address=request.POST.get('address')
        userreg(name=name,email=email,password=password,phone=phone,address=address).save()
        alert_message = "<script>alert('Registered successfully!'); window.location.href='/log';</script>"
        return HttpResponse(alert_message)
        return render(request,'login.html')
    return render(request,'register.html')

def userprofile(request):
    email=request.session['email']
    cr=userreg.objects.get(email=email)
    if cr:
        user_info={
            'name':cr.name,
            'email':cr.email,
            'password':cr.password,
            'phone':cr.phone,
            'address':cr.address,
        }
        return render(request,'userprofile.html',user_info)
    else:
        return render(request,'userprofile.html')
    
def updatepro(request):
    email=request.session['email']
    cr=userreg.objects.get(email=email)
    if cr:
        user_info={
            'name':cr.name,
            'email':cr.email,
            'password':cr.password,
            'phone':cr.phone,
            'address':cr.address,
        }
        return render(request,'updatepro.html',user_info)
    else:
        return render(request, 'updatepro.html')
    
def proupdate(request):
    email=request.session['email']
    if request.method=="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        password=request.POST.get('password')
        phone=request.POST.get('phone')
        address=request.POST.get('address')
        
        
        data=userreg.objects.get(email=email)
        data.name=name
        data.email=email
        data.password=password
        data.phone=phone
        data.address=address
        
        data.save()
        
        cr=userreg.objects.get(email=email)
        if cr:
            user_info={
            'name':cr.name,
            'email':cr.email,
            'password':cr.password,
            'phone':cr.phone,
            'address':cr.address,
            }
            
        return render(request,'userprofile.html',user_info)
    else:
        return render(request,'update.html')
    
                
                
def sellerregi(request):
    if request.method=='POST':
        name=request.POST.get('name')
        email=request.POST.get('email')
        password=request.POST.get('password')
        phone=request.POST.get('phone')
        sellerreg(name=name,email=email,password=password,phone=phone).save()
        alert_message = "<script>alert('Registered successfully!'); window.location.href='/sellerlog';</script>"
        return HttpResponse(alert_message)
        return redirect('/sellerlog/')
    return render(request,'sellreg.html')

def sellerprofile(request):
    email=request.session['email']
    cr=sellerreg.objects.get(email=email)
    if cr:
        user_info={
            'name':cr.name,
            'email':cr.email,
            'password':cr.password,
            'phone':cr.phone,
        }
        return render(request,'sellerprofile.html',user_info)
    else:
        return render(request,'sellerprofile.html')

    
def sellerpro(request):
    email=request.session['email']
    cr=sellerreg.objects.get(email=email)
    if cr:
        user_info={
            'name':cr.name,
            'email':cr.email,
            'password':cr.password,
            'phone':cr.phone,
        }
        return render(request,'sellerpro.html',user_info)
    else:
        return render(request, 'sellerpro.html')
    
def proseller(request):
    email=request.session['email']
    if request.method=="POST":
        name=request.POST.get('name')
        email=request.POST.get('email')
        password=request.POST.get('password')
        phone=request.POST.get('phone')
        
        
        
        data=sellerreg.objects.get(email=email)
        data.name=name
        data.email=email
        data.password=password
        data.phone=phone
        
        
        data.save()
        
        cr=sellerreg.objects.get(email=email)
        if cr:
            user_info={
            'name':cr.name,
            'email':cr.email,
            'password':cr.password,
            'phone':cr.phone,
           
            }
            
        return render(request,'sellerprofile.html',user_info)
    else:
        return render(request,'sellerpro.html')    
    





def log(request):
    if request.method=='POST':
        email=request.POST.get('email')
        password=request.POST.get('password')
        try:
            ur=userreg.objects.get(email=email,password=password)
            request.session['email']=ur.email
            request.session['id']=ur.id
            return render(request,'userhome.html')
        except userreg.DoesNotExist:
            return render(request,'register.html')
    return render(request,'login.html')
def sellerlog(request):
    if request.method=='POST':
        email=request.POST.get('email')
        password=request.POST.get('password')
        try:
            ur=sellerreg.objects.get(email=email,password=password)
            request.session['email']=ur.email
            request.session['id']=ur.id
            return render(request,'sellerhome.html')
        except sellerreg.DoesNotExist:
            return redirect('/sellerreg/')
    return render(request,'sellerlogin.html')          
def sellerhome(request):
    return render(request,'sellerhome.html')  
def userhome(request):
    return render(request,'userhome.html')
def logout(request):
    request.session.flush()
    return render(request,'index.html')
def addprod(request):
    if request.method == 'POST':
        productname = request.POST.get('productname')
        category = request.POST.get('category')
        price = request.POST.get('price')
        quantity = request.POST.get('quantity')
        description = request.POST.get('description')
        size = request.POST.get('size')
        gender = request.POST.get('gender')
        image = request.FILES['image']  # Accessing the uploaded file directly from request.FILES
        
        # Creating the AddProduct object
        product = addproduct(
            productname=productname,
            category=category,
            price=price,
            quantity=quantity,
            description=description,
            size=size,
            gender=gender,
            image=image
        )
        # Saving the AddProduct object
        product.save()
        alert_message = "<script>alert('Registered successfully!'); window.location.href='/sellerhome';</script>"
        return HttpResponse(alert_message)
        return render(request,'sellerhome.html')
    else:
        return render(request, 'selleraddproduct.html')
def viewproduct(request, category):
    products = addproduct.objects.filter(category=category)
    return render (request,'viewproduct.html',{'products': products, 'category':category})

# def cart(request,product_id):
    
#     uid=request.session['id']
#     usern= userreg.objects.get(id=uid)
#     if request.method == 'POST':
#         # Retrieve the product based on the provided product_id
#         product = addproduct.objects.get(pk=product_id)
        
#         # Create a new cart item for the logged-in user and the selected product
#         cart_item = Cartitem(user=usern, product=product)
#         cart_item.save()
        
#         # Optionally, you can display a success message
#         messages.success(request, f"{product.productname} added to cart successfully!")
        
#         # Redirect the user to a relevant page (e.g., the product page or the cart page)
#         return redirect('viewproduct')
    
#     # If the request method is not POST, handle accordingly (e.g., display an error message)
#     messages.error(request, "Failed to add product to cart. Please try again later.")
#     return redirect('viewproduct')
#     return render (request,'cart.html')

def cart(request,id):
    # Get the product
    dt = addproduct.objects.get(id=id)
    # Extract other product details
    a = dt.productname
    b = dt.description
    c = dt.quantity
    d = dt.price
    e = dt.image

    email=request.session['email']
    # print(name)
    cr=userreg.objects.get(email=email)

    name=cr.name


    return render(request, 'add_cart.html', {'productname': a, 'description': b, 'quantity': c, 'price': d, 'image':e,'name':name})


# add to cart views  

def add_cart(request):
    if request.method == 'POST':
        a = request.POST.get('productname')
        # b = request.POST.get('description')
        c= int(request.POST.get('quantity'))
        d = request.POST.get('price')
        e = request.POST.get('image')
        pr=int(d)
        to=int(c*pr)
        data=addproduct.objects.get(productname=a)
        qu=int(data.quantity)
        newqn=int(qu-c)
        data.quantity=newqn
        data.save()
        s = request.session['email']
        cr = userreg.objects.get(email=s)

        f = cr.email
        # g = cr.phone
        if newqn < 0:
            return render(request,'error.html')
        else:
            Cartitem(product=a, quantity=c, price=d,image=e, email=f,total=to).save()
            message="item added to cart successfully !"
            return render(request,'userhome.html',{'me':message})
    else:
        return render(request, 'add_cart.html')




def viewcart(request):
    email=request.session['email']
    acart = Cartitem.objects.filter(email=email)
    return render(request,'cart.html',{'acart': acart})



def payment(request):
    email=request.session['email']
    cr=Cartitem.objects.filter(email=email)
    data=userreg.objects.get(email=email)
    name=data.name
    totalprice = 0
   
    for i in cr:
     pay(email=i.email, product=i.product, price=i.total,name=name).save()
     totalprice=int(totalprice + i.total)
     i.delete()
    
    totalprice = int(totalprice*100)
    amount=int(totalprice)
    #amount=200
    print('amount is',str(amount))
    currency = 'INR'
    # amount = 20000  # Rs. 200

    # Create a Razorpay Order
    razorpay_order = razorpay_client.order.create(dict(amount=amount,
                                                       currency=currency,
                                                       payment_capture='0'))
 
    # order id of newly created order.
    razorpay_order_id = razorpay_order['id']
    callback_url = '/paymenthandler/'
 
    # we need to pass these details to frontend.
    context = {}
    context['razorpay_order_id'] = razorpay_order_id
    context['razorpay_merchant_key'] = settings.RAZOR_KEY_ID
    context['razorpay_amount'] = amount
    context['currency'] = currency
    context['callback_url'] = callback_url
 
    return render(request, 'payment.html', context=context)
 
@csrf_exempt
def paymenthandler(request):
 
    # only accept POST request.
    if request.method == "POST":
        try:
           
            # get the required parameters from post request.
            payment_id = request.POST.get('razorpay_payment_id', '')
            razorpay_order_id = request.POST.get('razorpay_order_id', '')
            signature = request.POST.get('razorpay_signature', '')
            params_dict = {
                'razorpay_order_id': razorpay_order_id,
                'razorpay_payment_id': payment_id,
                'razorpay_signature': signature
            }
 
            # verify the payment signature.
            result = razorpay_client.utility.verify_payment_signature(
                params_dict)
            if result is not None:
                amount = 20000  # Rs. 200
                try:
 
                    # capture the payemt
                    razorpay_client.payment.capture(payment_id, amount)
 
                    # render success page on successful caputre of payment
                    return render(request, 'pay_success.html')
                except:
 
                    # if there is an error while capturing payment.
                    return render(request, 'pay_success.html')
            else:
 
                # if signature verification fails.
                return render(request, 'pay_success.html')
        except:
 
            # if we don't find the required parameters in POST data
            return HttpResponseBadRequest()
    else:
       # if other than POST request is made.
        return HttpResponseBadRequest()


def paylist(request):
    data=pay.objects.all()
    return render(request, 'paylist.html', {'data': data})


def accept(request, id):
    email_obj = pay.objects.get(id=id)
    email_user = email_obj.email
    print(email_user)
    email_obj.is_accepted = True
    email_obj.save()

    smtp_server = 'smtp.gmail.com'
    smtp_port = 587
    sender_email = 'nefsal003@gmail.com'
    sender_password = 'htxalvzrrkxupspv'

    message = "Subject: Order Confirmation\n\nDear Customer,\n\nWe're pleased to inform you that your order has been successfully processed. Thank you for choosing our service.\n\nBest regards,\nThe Sports Sphere Team"


    with smtplib.SMTP(smtp_server, smtp_port) as server:
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, email_user, message)

    return render(request, 'sellerhome.html')

def delete(request,id):
    data=Cartitem.objects.get(id=id)
    data.delete()
    return render(request,'userhome.html')

def search(request):
    if request.method == 'POST':
        cat = request.POST.get('productname')
    
        print(cat)

        data = addproduct.objects.filter(productname=cat).values()
        
        if data.exists():
           
            
            return render(request, 'search.html', {'datas': data})
        else:
            messages.warning(request, 'Item not found!')
            return render(request, 'search.html')
    else:
        return render(request, 'search.html')
    
from django.shortcuts import render, redirect
from django.core.mail import send_mail

from Sports_Sphere.models import userreg  # Import your custom userreg model


# from django.shortcuts import render, redirect
# from .models import addproduct
# from .forms import ProductStatusForm

# def product_list(request):
#     products = pay.objects.all()
#     return render(request, 'product_list.html', {'products': products})

# def update_product_status(request, product_id):
#     product = pay.objects.get(pk=product_id)
#     form = ProductStatusForm(request.POST or None, instance=product)
#     if form.is_valid():
#         form.save()
#         return redirect('/product_list/')
#     return render(request, 'update_product_status.html', {'form': form, 'product': product})
def payment_list(request, product_id=None):
    payments = pay.objects.filter(send_to_delivery_agent=True)
    return render(request, 'product_list.html', {'payments': payments})

def sellerdellist(request, product_id=None):
    payments = pay.objects.filter(send_to_delivery_agent=True)
    return render(request, 'sellerdelupdates.html', {'payments': payments})
from django.shortcuts import redirect, get_object_or_404
from .models import pay

def update_payment_status(request, payment_id):
    payment = get_object_or_404(pay, pk=payment_id)
    if request.method == 'POST':
        new_status = request.POST.get('status')
        payment.status = new_status
        payment.save()
    return redirect('/payment_list/')


from django.shortcuts import redirect
from .models import pay



from .models import addproduct
from .models import addproduct

def sorted_product_list(request):
    # Retrieve all products
    products = addproduct.objects.all()
    
    # Default sorting by product name
    sort_by = request.GET.get('sort_by', 'productname')
    
    # Sort products based on user selection
    if sort_by == 'price':
        products = products.order_by('-price')
    elif sort_by == 'size':
        products = products.order_by('size')
    
    return render(request, 'sorted_product_list.html', {'products': products})

from .models import addproduct

def viewproduct(request, category):
    # Retrieve all products
    products = addproduct.objects.filter(category=category)

    # Default sorting by product name
    sort_by = request.POST.get('sort_by', 'productname')

    # Sort products based on user selection
    if sort_by == 'price_high':
        products = products.order_by('-price')
    elif sort_by == 'price_low':
        products = products.order_by('price')
    elif sort_by == 'quantity_high':
        products = products.order_by('-quantity')
    elif sort_by == 'quantity_low':
        products = products.order_by('quantity')
    elif sort_by == 'size_high':
        products = products.order_by('-size')
    elif sort_by == 'size_low':
        products = products.order_by('size')

    return render(request, 'viewproduct.html', {'products': products, 'category': category, 'sort_by': sort_by})

def delreg(request):
    if request.method=='POST':
        name=request.POST.get('name')
        email=request.POST.get('email')
        password=request.POST.get('password')
        phone=request.POST.get('phone')
        Delivery(name=name,email=email,password=password,phone=phone).save()
        alert_message = "<script>alert('Registered successfully!'); window.location.href='/log';</script>"
        return HttpResponse(alert_message)
        return render(request,'login.html')
    return render(request,'delilogin.html')


def delilog(request):
    if request.method=='POST':
        email=request.POST.get('email')
        password=request.POST.get('password')
        try:
            ur=Delivery.objects.get(email=email,password=password)
            request.session['email']=ur.email
            request.session['id']=ur.id
            return render(request,'delhome.html')
        except Delivery.DoesNotExist:
            return render(request,'delireg.html')
    return render(request,'delilogin.html')